"""
Streamlit web app — Stress Concentration & Safety Factor Estimator
Run with:  streamlit run app.py
"""

import streamlit as st
import plotly.graph_objects as go
import pandas as pd
import math

from stress_analysis import (
    Material, GeometryFeature, LoadCase, AnalysisResult,
    FeatureType, LoadType, FailureCriterion,
    analyse, circular_section, MATERIAL_LIBRARY,
)

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Stress Concentration Estimator",
    page_icon="⚙️",
    layout="wide",
)

st.title("⚙️ Stress Concentration & Safety Factor Estimator")
st.caption(
    "Estimates peak stresses and safety factors for common mechanical stress raisers "
    "using Pilkey & Peterson curve-fit formulas."
)
st.divider()

# ── Sidebar — inputs ──────────────────────────────────────────────────────────
with st.sidebar:
    st.header("Inputs")

    # ── Material ──
    st.subheader("1 · Material")
    mat_options = {v.name: k for k, v in MATERIAL_LIBRARY.items()}
    mat_options["Custom…"] = "__custom__"
    mat_choice = st.selectbox("Material", list(mat_options.keys()), index=1)

    if mat_options[mat_choice] == "__custom__":
        c1, c2, c3 = st.columns(3)
        cSy = c1.number_input("Sy (MPa)", value=250, min_value=1)
        cSu = c2.number_input("Su (MPa)", value=400, min_value=1)
        cSe = c3.number_input("Se (MPa)", value=200, min_value=1)
        material = Material(
            name="Custom", yield_strength=cSy,
            ultimate_strength=cSu, endurance_limit=cSe, elastic_modulus=200
        )
    else:
        material = MATERIAL_LIBRARY[mat_options[mat_choice]]

    st.divider()

    # ── Geometry feature ──
    st.subheader("2 · Stress Raiser")
    feat_map = {
        "Circular hole in flat plate": FeatureType.CIRCULAR_HOLE,
        "Shoulder fillet — shaft":     FeatureType.SHOULDER_FILLET,
        "Circumferential U-groove":    FeatureType.GROOVE,
        "Keyway":                      FeatureType.KEYWAY,
        "Press fit":                   FeatureType.PRESS_FIT,
    }
    feat_label = st.selectbox("Feature type", list(feat_map.keys()), index=1)
    feat_type  = feat_map[feat_label]

    # Dynamic dimension inputs
    geo_kwargs = {"feature_type": feat_type}

    if feat_type == FeatureType.CIRCULAR_HOLE:
        W  = st.number_input("Plate width W (mm)",      value=80.0,  min_value=1.0)
        th = st.number_input("Plate thickness t (mm)",  value=10.0,  min_value=0.1)
        dh = st.number_input("Hole diameter d (mm)",    value=20.0,  min_value=0.1)
        geo_kwargs.update(width=W, height=th, hole_diameter=dh)

    elif feat_type == FeatureType.SHOULDER_FILLET:
        D  = st.number_input("Large diameter D (mm)",   value=50.0,  min_value=1.0)
        d  = st.number_input("Reduced diameter d (mm)", value=38.0,  min_value=1.0)
        r  = st.number_input("Fillet radius r (mm)",    value=3.0,   min_value=0.1, step=0.5)
        geo_kwargs.update(width=D, height=d, fillet_radius=r)

    elif feat_type == FeatureType.GROOVE:
        D  = st.number_input("Large diameter D (mm)",      value=50.0, min_value=1.0)
        d  = st.number_input("Root diameter d (mm)",       value=38.0, min_value=1.0)
        r  = st.number_input("Root radius r (mm)",         value=3.0,  min_value=0.1, step=0.5)
        geo_kwargs.update(width=D, height=d, groove_radius=r)

    elif feat_type == FeatureType.KEYWAY:
        d  = st.number_input("Shaft diameter d (mm)", value=40.0, min_value=1.0)
        geo_kwargs.update(width=d)

    elif feat_type == FeatureType.PRESS_FIT:
        d  = st.number_input("Shaft diameter d (mm)", value=50.0, min_value=1.0)
        geo_kwargs.update(width=d)

    st.divider()

    # ── Load case ──
    st.subheader("3 · Load Case")
    load_map = {
        "Axial (tension / compression)": LoadType.AXIAL,
        "Bending":                        LoadType.BENDING,
        "Torsion":                        LoadType.TORSION,
        "Combined (axial + bending)":     LoadType.COMBINED,
    }
    load_label = st.selectbox("Load type", list(load_map.keys()), index=1)
    load_type  = load_map[load_label]

    force   = 0.0
    moment  = 0.0
    torque  = 0.0

    if load_type in (LoadType.AXIAL, LoadType.COMBINED):
        force = st.number_input("Axial force F (N)", value=0.0, min_value=0.0, step=500.0)
    if load_type in (LoadType.BENDING, LoadType.COMBINED):
        moment = st.number_input("Bending moment M (N·mm)", value=1_200_000.0, min_value=0.0, step=10_000.0)
    if load_type == LoadType.TORSION:
        torque = st.number_input("Torque T (N·mm)", value=850_000.0, min_value=0.0, step=10_000.0)

    st.divider()

    crit_map = {
        "Von Mises (ductile, general)": FailureCriterion.VON_MISES,
        "Tresca (conservative ductile)": FailureCriterion.TRESCA,
        "Max Normal (brittle)":          FailureCriterion.MAX_NORMAL,
    }
    crit_label = st.selectbox("Failure criterion", list(crit_map.keys()))
    criterion  = crit_map[crit_label]

    run = st.button("▶  Calculate", type="primary", use_container_width=True)


# ── Main panel ────────────────────────────────────────────────────────────────

if not run:
    st.info("Configure inputs in the sidebar, then click **▶ Calculate**.")
    st.stop()

# Build objects and run
try:
    feature  = GeometryFeature(**geo_kwargs)

    # Auto section properties
    lc_kwargs = dict(load_type=load_type, axial_force=force,
                     bending_moment=moment, torque=torque)
    if feat_type != FeatureType.CIRCULAR_HOLE:
        shaft_d = geo_kwargs.get("height") or geo_kwargs.get("width")
        A, Z, Zp = circular_section(shaft_d)
        lc_kwargs.update(cross_section_area=A, section_modulus=Z, polar_section_mod=Zp)
    else:
        net_area = (geo_kwargs["width"] - geo_kwargs["hole_diameter"]) * geo_kwargs["height"]
        lc_kwargs["cross_section_area"] = net_area

    load   = LoadCase(**lc_kwargs)
    result = analyse(feature, load, material, criterion)

except Exception as e:
    st.error(f"**Calculation error:** {e}")
    st.stop()

d = result.details

# ── KPI cards ──
st.subheader("Key Results")
k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("Stress Conc. Kt",    f"{result.Kt:.3f}")
k2.metric("Peak σ_eq",          f"{result.peak_stress:.1f} MPa")
k3.metric("SF — Yield",         f"{result.safety_factor_yield:.2f}",
          delta="OK" if result.safety_factor_yield >= 1.5 else "LOW",
          delta_color="normal" if result.safety_factor_yield >= 1.5 else "inverse")
k4.metric("SF — Fatigue",       f"{result.safety_factor_fatigue:.2f}",
          delta="OK" if result.safety_factor_fatigue >= 2.0 else "LOW",
          delta_color="normal" if result.safety_factor_fatigue >= 2.0 else "inverse")
k5.metric("SF — Ultimate",      f"{result.safety_factor_ultimate:.2f}",
          delta="OK" if result.safety_factor_ultimate >= 2.0 else "LOW",
          delta_color="normal" if result.safety_factor_ultimate >= 2.0 else "inverse")

st.divider()

# ── Charts + detail ──
col_left, col_right = st.columns([1.1, 0.9])

with col_left:
    # Safety factor gauge chart
    st.subheader("Safety Factor Gauge")

    def gauge(value, title, target):
        color = "#3a9e5a" if value >= target else ("#e07b39" if value >= 1.0 else "#c0392b")
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=round(value, 2),
            title={"text": title, "font": {"size": 13}},
            number={"font": {"size": 22}},
            gauge={
                "axis": {"range": [0, max(4, value * 1.2)], "tickwidth": 1},
                "bar":  {"color": color, "thickness": 0.3},
                "steps": [
                    {"range": [0, 1.0],    "color": "#fde8e8"},
                    {"range": [1.0, target], "color": "#fef3cd"},
                    {"range": [target, max(4, value * 1.2)], "color": "#d4edda"},
                ],
                "threshold": {
                    "line": {"color": "#333", "width": 2},
                    "thickness": 0.75,
                    "value": target,
                },
            },
        ))
        fig.update_layout(height=200, margin=dict(t=40, b=10, l=20, r=20))
        return fig

    g1, g2, g3 = st.columns(3)
    g1.plotly_chart(gauge(result.safety_factor_yield,   "Yield",   1.5), use_container_width=True)
    g2.plotly_chart(gauge(result.safety_factor_fatigue, "Fatigue", 2.0), use_container_width=True)
    g3.plotly_chart(gauge(result.safety_factor_ultimate,"Ultimate",2.0), use_container_width=True)

    # Stress waterfall bar chart
    st.subheader("Stress Breakdown")
    stress_labels = ["Nominal σ", "Peak σ (Kt·σ_nom)", "Equiv. σ_eq", "Sy", "Su"]
    stress_values = [
        d["nominal_normal_stress_MPa"] or d["nominal_shear_stress_MPa"],
        d["peak_normal_stress_MPa"]    or d["peak_shear_stress_MPa"],
        d["equivalent_stress_MPa"],
        material.yield_strength,
        material.ultimate_strength,
    ]
    bar_colors = ["#5b8dd9", "#e07b39", "#c0392b", "#3a9e5a", "#2ecc71"]
    fig_bar = go.Figure(go.Bar(
        x=stress_labels, y=stress_values,
        marker_color=bar_colors,
        text=[f"{v:.1f}" for v in stress_values],
        textposition="outside",
    ))
    fig_bar.update_layout(
        yaxis_title="Stress (MPa)",
        height=320,
        margin=dict(t=20, b=10, l=40, r=20),
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
    )
    st.plotly_chart(fig_bar, use_container_width=True)

with col_right:
    st.subheader("Full Stress Report")

    report_data = {
        "Parameter": [
            "Material", "Feature type", "Load type", "Failure criterion",
            "―",
            "Nominal normal stress", "Nominal shear stress",
            "Stress conc. factor Kt",
            "Peak normal stress", "Peak shear stress",
            "Equivalent stress σ_eq",
            "――",
            "Yield strength Sy", "UTS Su", "Endurance limit Se",
            "―――",
            "Safety factor — Yield", "Safety factor — Fatigue", "Safety factor — UTS",
        ],
        "Value": [
            material.name, feat_label, load_label, crit_label,
            "",
            f"{d['nominal_normal_stress_MPa']:.3f} MPa",
            f"{d['nominal_shear_stress_MPa']:.3f} MPa",
            f"{result.Kt:.4f}",
            f"{d['peak_normal_stress_MPa']:.3f} MPa",
            f"{d['peak_shear_stress_MPa']:.3f} MPa",
            f"{d['equivalent_stress_MPa']:.3f} MPa",
            "",
            f"{material.yield_strength:.1f} MPa",
            f"{material.ultimate_strength:.1f} MPa",
            f"{material.endurance_limit:.1f} MPa",
            "",
            f"{result.safety_factor_yield:.3f}",
            f"{result.safety_factor_fatigue:.3f}",
            f"{result.safety_factor_ultimate:.3f}",
        ],
    }
    st.dataframe(
        pd.DataFrame(report_data),
        hide_index=True,
        use_container_width=True,
        height=580,
    )

st.divider()

# ── Warnings / status ──
st.subheader("Design Assessment")
if result.warnings:
    for w in result.warnings:
        if "⚠" in w or "YIELDING" in w or "FATIGUE FAILURE" in w:
            st.error(w)
        else:
            st.warning(w)
else:
    st.success("✅ No critical warnings. Component appears adequate under specified loading.")

# ── Sensitivity: SF vs fillet radius (only for shoulder fillet) ──
if feat_type == FeatureType.SHOULDER_FILLET and feat_label == "Shoulder fillet — shaft":
    st.divider()
    st.subheader("Parametric Sensitivity — SF vs Fillet Radius")
    st.caption("How safety factors change as the fillet radius varies (all other parameters fixed).")

    radii = [x * 0.5 for x in range(1, 41)]  # 0.5 mm to 20 mm
    sf_y_list, sf_f_list, sf_u_list = [], [], []

    for rr in radii:
        try:
            g_tmp = GeometryFeature(
                feature_type=FeatureType.SHOULDER_FILLET,
                width=geo_kwargs["width"], height=geo_kwargs["height"], fillet_radius=rr
            )
            shaft_d2 = geo_kwargs["height"]
            A2, Z2, Zp2 = circular_section(shaft_d2)
            lc_tmp = LoadCase(
                load_type=load_type, axial_force=force,
                bending_moment=moment, torque=torque,
                cross_section_area=A2, section_modulus=Z2, polar_section_mod=Zp2,
            )
            res_tmp = analyse(g_tmp, lc_tmp, material, criterion)
            sf_y_list.append(res_tmp.safety_factor_yield)
            sf_f_list.append(res_tmp.safety_factor_fatigue)
            sf_u_list.append(res_tmp.safety_factor_ultimate)
        except Exception:
            sf_y_list.append(None)
            sf_f_list.append(None)
            sf_u_list.append(None)

    fig_sens = go.Figure()
    fig_sens.add_trace(go.Scatter(x=radii, y=sf_y_list, name="SF Yield",   line=dict(color="#3a9e5a", width=2)))
    fig_sens.add_trace(go.Scatter(x=radii, y=sf_f_list, name="SF Fatigue", line=dict(color="#5b8dd9", width=2)))
    fig_sens.add_trace(go.Scatter(x=radii, y=sf_u_list, name="SF UTS",     line=dict(color="#2ecc71", width=2, dash="dash")))
    fig_sens.add_hline(y=1.5, line_dash="dot", line_color="orange", annotation_text="SF = 1.5")
    fig_sens.add_hline(y=2.0, line_dash="dot", line_color="red",    annotation_text="SF = 2.0")
    fig_sens.add_vline(x=r, line_dash="dash", line_color="#888", annotation_text=f"Current r = {r} mm")
    fig_sens.update_layout(
        xaxis_title="Fillet radius r (mm)",
        yaxis_title="Safety factor",
        height=360,
        margin=dict(t=20, b=30, l=50, r=20),
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        legend=dict(orientation="h", yanchor="bottom", y=1.01),
    )
    st.plotly_chart(fig_sens, use_container_width=True)

st.divider()
st.caption("Formulas: Pilkey & Pilkey *Peterson's Stress Concentration Factors* (3rd ed.). "
           "For design verification only — always consult a qualified engineer.")
